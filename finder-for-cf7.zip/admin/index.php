<?php // Silence is golden
defined('ABSPATH') || exit;