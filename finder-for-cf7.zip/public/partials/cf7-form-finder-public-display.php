<?php
defined('ABSPATH') || exit;
/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://github.com/Dev-Atmos/contact-form7-finder
 * @since      1.0.0
 *
 * @package    Finder_for_CF7
 * @subpackage Finder_for_CF7/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
